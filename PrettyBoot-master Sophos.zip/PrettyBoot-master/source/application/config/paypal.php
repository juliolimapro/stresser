<?php

return array(
	
		'username' => '',
		'password' => '',
		'signature' => '',
        'currency' => 'USD'


);

