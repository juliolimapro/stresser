@layout('main')


@section('content')

<h3>Payment cancelled</h3>

    <p>
        You seemt to have cancelled your payment, try again whenever you want! :)
    </p>

@endsection