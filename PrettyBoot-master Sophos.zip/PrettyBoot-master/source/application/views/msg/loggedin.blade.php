@layout('user')


@section('meta')
<meta http-equiv="refresh" content="2;url=/">
@endsection

@section('content')
Successful login!
@endsection

