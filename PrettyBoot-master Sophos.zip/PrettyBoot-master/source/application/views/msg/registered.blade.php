@layout('user')


@section('content')

<div>
    Thank you for registering! <br />
    <br />
    You are now able to login with your account and select your preferred plan.
    <br /><br />
    <a href="/user/login" style="width:200px;" class="btn btn-danger">Login</a>
</div>

@endsection