@layout('main')


@section('content')
<div style="width:100%; text-align:center;">
    <h2>We're sorry...</h2>
    <p>
        There went something wrong on our end, we are trying to fix it as soon as possible!<br />

        <a href="javascript:history.go(-1)">Click here to go back!</a>
    </p>
</div>
@endsection